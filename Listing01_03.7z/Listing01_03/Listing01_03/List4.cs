﻿using Microsoft.VisualBasic;
using System.Windows.Forms;
class InputDialogDemo
{static void Main()
    {
        string name;
        name = Interaction.InputBox("What is your name?",
            "Lets get acquainted.." );
        string txt="Very nice, "+name+"!";
        MessageBox.Show(txt, "The acquanintance took place");
    }
}